<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row gx-5">
        <div class="col-8 bg-warning">
            POSTS
        </div>
        <div class="col-4 bg-secondary">
            
            PROFILE OVERVIEW +

            
            SUGGESTIONS
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kredo\dev3-laravel\laravel-insta\resources\views/users/home.blade.php ENDPATH**/ ?>