@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <div class="row gx-5">
        <div class="col-8 bg-warning">
            POSTS
        </div>
        <div class="col-4 bg-secondary">
            {{-- Profile Overview --}}
            PROFILE OVERVIEW +

            {{-- Suggestions --}}
            SUGGESTIONS
        </div>
    </div>
@endsection
