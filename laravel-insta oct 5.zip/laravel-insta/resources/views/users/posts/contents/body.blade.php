{{-- Clickable image --}}
<div class="container p-0">
    <a href="#">
        <img src="{{ $post->image }}" alt="post id {{ $post->id }}" class="w-100">
    </a>
</div>
<div class="card-body">
    {{-- heart button + no. of likes + categories --}}
    <div class="row align-items-center">
        <div class="col-auto">
            <form action="#" method="post">
                @csrf
                <button type="submit" class="btn btn-sm shadow-none p-0"><i class="fa-regular fa-heart"></i></button>
            </form>
        </div>
    </div>
</div>